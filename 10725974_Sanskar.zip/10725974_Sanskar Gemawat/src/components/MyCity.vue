<template>
  <div>
    <h4>Native Hometown: Jodhpur</h4>
    <p>
      Situated on the edge of the Thar Desert, Jodhpur is also called the “Sun
      City,” named for the overwhelming amount of bright and sunny days it
      experiences. It is home to famed forts, palaces, mausoleums, gardens,
      lakes, and towers, making it a hotspot for tourist activity.
    </p>
  </div>
  <div>
    <img src="~C:\PASSPORT SIZE PHOTO\jodhpur.jpg" />
  </div>
</template>
<style scoped>
h4 {
  color: rgb(181, 56, 34);
  background-color: lightsalmon;
  font-family: monospace;
  font-weight: bold;
  font-style: italic;
  text-align: center;
}
img {
  float: center;
  align-content: center;
  max-width: 500px;
  height: 300px;
}
p {
  font-size: large;
  font-style: italic;
  font-family: "Times New Roman", Times, serif;
  background-color: rgb(170, 74, 68);
  text-align: justify;
  color: white;
}
</style>
