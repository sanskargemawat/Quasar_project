<template>
  <div class="hobbies">
    <h3>My Hobbies</h3>
    <p>
      I Love playing Cricket, Badminton and also like exploring different
      Sports.
    </p>
    <p>I also like Travelling specially the Adventures.</p>
    <p>I like socialising and exploring new things.</p>
  </div>
</template>

<style scoped>
h3 {
  text-align: center;
  color: darkred;
  background-color: darksalmon;
  font-family: monospace;
  font-weight: bold;
  font-style: italic;
  text-decoration-line: underline;
}
p {
  font-size: xx-large;
  font-style: italic;
  font-family: "Times New Roman", Times, serif;
  background-color: darkseagreen;
}
</style>
