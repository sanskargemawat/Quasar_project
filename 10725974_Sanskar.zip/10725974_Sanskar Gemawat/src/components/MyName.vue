<template>
  <body>
    <div class="profile">
      <h4>ABOUT ME</h4>
      <p>
        My Name is Sanskar Gemawat and I am Jodhpur, Rajasthan. I have done my
        Graduation from Mumbai in the stream of Electronics & Telecommunication.
        I am also looking forward to work with LTIMINDTREE.
      </p>
    </div>
  </body>
</template>
<style scoped>
h4 {
  color: darkcyan;
  background-color: azure;
  font-family: monospace;
  font-weight: bold;
  font-style: italic;
  text-align: center;
  text-decoration: underline;
}
p {
  font-size: xx-large;
  font-style: italic;
  font-family: "Times New Roman", Times, serif;
  background-color: cadetblue;
}
</style>
