<template>
  <div>
    <h3>Technical Skills</h3>
    <ul class="list">
      <li>Programming Languages : Python, Java, C++</li>
      <li>Other Skills : Docker, Kubernetes, AI/ML basics</li>
      <li>Also proficient with MS-WORD, MS-Excel and MS-Powerpoint</li>
      <li>Have done simulation on Windows and Linux Infra</li>
    </ul>
  </div>
</template>
<style scoped>
h3 {
  text-align: center;
  color: brown;
  background-color: rgb(231, 118, 69);
  font-family: monospace;
  font-weight: bold;
  font-style: italic;
  text-decoration-line: underline;
}
.list {
  font-size: xx-large;
  font-style: italic;
  font-family: "Times New Roman", Times, serif;
  background-color: chocolate;
}
</style>
