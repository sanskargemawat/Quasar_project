<template>
  <!-- <q-page class="flex flex-center">
    <img
      alt="Quasar logo"
      src="~assets/quasar-logo-vertical.svg"
      style="width: 200px; height: 200px"
    >
  </q-page> -->
  <!-- <h1>Hi this is Sanskar doing some work</h1> -->
  <!--
Forked from:
https://quasar.dev/vue-components/card#example--cards-with-media-content
-->
  <div id="q-app" style="min-height: 100vh; background-color: honeydew">
    <div class="q-pa-md">
      <div class="q-col-gutter-md row justify-center items-center">
        <q-parallax src="~src\assets\bg2.png">
          <div class="col-6">
            <q-img src="src\assets\MyPhoto.jpg">
              <div class="absolute-bottom text-subtitle1 text-center">
                Sanskar Gemawat
              </div>
            </q-img>
          </div>
          <br />
          <div class="name">
            <q-btn
              color="red"
              class="name-button"
              label="ABOUT ME"
              @click="($event) => $router.push('/sanskar/name')"
            />
          </div>
          <br />
          <div class="hobbies">
            <q-btn
              color="blue"
              class="hobbies-button"
              label="Hobbies & Interests"
              @click="($event) => $router.push('/sanskar/hobbies')"
            />
          </div>
          <br />
          <div class="location">
            <q-btn
              color="orange"
              class="city-button"
              label="Hometown"
              @click="($event) => $router.push('/sanskar/city')"
            />
          </div>
          <br />
          <div>
            <q-btn
              color="pink"
              class="skills-button"
              label="Technical Skills"
              @click="($event) => $router.push('/sanskar/skills')"
            />
          </div>
          <br />
        </q-parallax>
      </div>
    </div>
  </div>

  <!-- <q-card-actions>
        <q-btn flat>Action 1</q-btn>
        <q-btn flat>Action 2</q-btn>
      </q-card-actions> -->
</template>
<style scoped>
.col-6 {
  align-content: center;
  width: 200px;
  height: 200px;
}
h3 {
  color: darkcyan;
  background-color: azure;
  font-family: monospace;
  font-weight: bold;
  text-align: center;
  /* text-decoration: underline; */
  font-family: "Times New Roman", Times, serif;
}
q-app {
  background-color: cadetblue;
  color: brown;
}
</style>
<script>
import { defineComponent } from "vue";

export default defineComponent({
  name: "IndexPage",
});
</script>
