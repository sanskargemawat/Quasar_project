const routes = [
  {
    path: "/sanskar/",
    component: () => import("layouts/MainLayout.vue"),
    children: [
      { path: "", component: () => import("pages/IndexPage.vue") },
      {
        path: "name",
        component: () => import("components/MyName.vue"),
      },
      {
        path: "city",
        component: () => import("components/MyCity.vue"),
      },
      {
        path: "hobbies",
        component: () => import("components/MyHobbies.vue"),
      },
      {
        path: "skills",
        component: () => import("components/MySkills.vue"),
      },
    ],
  },

  // Always leave this as last one,
  // but you can also remove it
  {
    path: "/:catchAll(.*)*",
    component: () => import("pages/ErrorNotFound.vue"),
  },
];

export default routes;
